<?php

namespace App\Http\Controllers\Permission;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class RoleController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api');
    }

    public function allPermissions(){
        try{
            $permissions = Permission::get();
            return $this->response(true, $permissions, 200);
        }catch(Exception $exception){
            return $this->response(false, $exception->getMessage(), 400);
        }

    }

    public function addPermission(Request $request){
        $validator = Validator::make($request->all(), [
            'name' => ['required', 'string', 'unique:permissions,name']

        ]);
        //
        if ($validator->fails()) {
            $error = $validator->messages()->first();
            return $this->response(false, $error, 400);
        }
        //
        try{
            $postData = $request->all();
            //Save inside DB
            $permission = Permission::create($postData);
            //
            return $this->response(true, $permission, 200);
        }catch(Exception $exception){
            return $this->response(false, $exception->getMessage(), 400);
        }

    }

    public function updatePermission(Request $request, $id){
        $validator = Validator::make($request->all(), [
            'name' => ['required', 'string', 'unique:permissions,name']

        ]);
        //
        if ($validator->fails()) {
            $error = $validator->messages()->first();
            return $this->response(false, $error, 400);
        }
        //
        try{
            $postData = $request->all();
            //Save inside DB
            $permission = Permission::where('id', $id)->update($postData);
            //
            return $this->response(true, "Permission updated", 200);
        }catch(Exception $exception){
            return $this->response(false, $exception->getMessage(), 400);
        }

    }

    public function deletePermission(Request $request, $id){
        try{
            $postData = $request->all();
            //Save inside DB
            $permission = Permission::where('id', $id)->delete();
            //
            return $this->response(true, "Permission deleted", 200);
        }catch(Exception $exception){
            return $this->response(false, $exception->getMessage(), 400);
        }

    }
}
